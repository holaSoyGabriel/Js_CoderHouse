/** @format */

const MAX_DATOS = 5;
let usuarios = [];
let cantidadUsuarios = 0;
let carrito = [];
const productosCosmeticos = [
	{ nombre: "Crema Facial", precio: 10 },
	{ nombre: "Shampoo", precio: 8 },
	{ nombre: "Perfume", precio: 25 },
];
const productosAlimenticios = [
	{ nombre: "Pan", precio: 2 },
	{ nombre: "Leche", precio: 1.5 },
	{ nombre: "Queso", precio: 5 },
];

function registrarUsuario() {
	if (cantidadUsuarios >= MAX_DATOS) {
		console.log("No se pueden registrar más usuarios ⚠️");
		return;
	}

	let nombre, apellido, edad;

	do {
		nombre = prompt("Ingrese su nombre:");
	} while (!nombre.trim());

	do {
		apellido = prompt("Ingrese su apellido:");
	} while (!apellido.trim());

	do {
		edad = prompt("Ingrese su edad:");
		if (!isNaN(edad) && parseInt(edad) > 0) {
			edad = parseInt(edad);
		} else {
			alert("La edad ingresada no es válida.");
		}
	} while (isNaN(edad) || parseInt(edad) <= 0);

	if (edad < 18) {
		alert(
			"Eres menor de edad y no podrás realizar compras. Solo quedas registrado."
		);
		usuarios.push({ nombre, apellido, edad });
		cantidadUsuarios++;
		console.log("Usuario menor de edad registrado correctamente ✅");
		return;
	}

	usuarios.push({ nombre, apellido, edad });
	cantidadUsuarios++;
	console.log("Usuario registrado correctamente ✅");
}

function verUsuariosRegistrados() {
	if (cantidadUsuarios === 0) {
		console.log("No hay usuarios registrados 🤷‍♂️");
		return;
	}

	usuarios.forEach((usuario, index) => {
		console.log(`Usuario ${index + 1}:`);
		console.log(`Nombre: ${usuario.nombre}`);
		console.log(`Apellido: ${usuario.apellido}`);
		console.log(`Edad: ${usuario.edad}`);
	});
}

function resetearUsuarios() {
	usuarios = [];
	cantidadUsuarios = 0;
	console.log("Registros reiniciados 🔄");
}

function agregarAlCarrito() {
	let opcionCategoria;
	do {
		opcionCategoria = prompt(
			`Submenú: 
1. Productos Cosméticos
2. Productos Alimenticios
3. Volver al Menú Principal
`
		);

		switch (opcionCategoria) {
			case "1":
				seleccionarProducto(productosCosmeticos, "Cosméticos");
				break;
			case "2":
				seleccionarProducto(productosAlimenticios, "Alimenticios");
				break;
			case "3":
				console.log("Volviendo al menú principal...");
				break;
			default:
				console.log("Opción inválida ❌");
		}
	} while (opcionCategoria !== "3");
}

function seleccionarProducto(productos, categoria) {
	let listaProductos = `Productos ${categoria}:`;
	productos.forEach((producto, index) => {
		listaProductos += `
${index + 1}. ${producto.nombre}= $${producto.precio}`;
	});
	listaProductos += `
${productos.length + 1}. Volver`;

	let opcionProducto;
	do {
		opcionProducto = parseInt(prompt(listaProductos));
		if (opcionProducto >= 1 && opcionProducto <= productos.length) {
			const productoSeleccionado = productos[opcionProducto - 1];
			carrito.push(productoSeleccionado);
			alert(`Agregaste "${productoSeleccionado.nombre}" al carrito.`);
			console.log(
				`Producto agregado: ${productoSeleccionado.nombre} - $${productoSeleccionado.precio}`
			);
		} else if (opcionProducto === productos.length + 1) {
			console.log("Volviendo al submenú...");
		} else {
			console.log("Opción inválida ❌");
		}
	} while (opcionProducto !== productos.length + 1);
}

function verCarrito() {
	if (carrito.length === 0) {
		console.log("El carrito está vacío 🛒");
		return;
	}

	console.log("Productos en el carrito:");
	carrito.forEach((producto, index) => {
		console.log(`${index + 1}. ${producto.nombre} = $${producto.precio}`);
	});

	const total = carrito.reduce((suma, producto) => suma + producto.precio, 0);
	console.log(`Total: $${total.toFixed(2)}`);
}

function menu() {
	let opcion;
	do {
		opcion = prompt(
			`
Simulador de Compras y Registro:

Este simulador permite registrar usuarios y calcular el total de 
compras interactuando desde la Consola JS.

Menú: 
1. Registrarse 
2. Ver usuarios registrados 
3. Agregar productos al carrito 
4. Ver carrito 
5. Resetear datos 
6. Salir
`
		);

		switch (opcion) {
			case "1":
				registrarUsuario();
				break;
			case "2":
				verUsuariosRegistrados();
				break;
			case "3":
				agregarAlCarrito();
				break;
			case "4":
				verCarrito();
				break;
			case "5":
				resetearUsuarios();
				break;
			case "6":
				console.log("¡Hasta luego! 👋");
				break;
			default:
				console.log("Opción inválida ❌");
		}
	} while (opcion !== "6");
}

menu();
